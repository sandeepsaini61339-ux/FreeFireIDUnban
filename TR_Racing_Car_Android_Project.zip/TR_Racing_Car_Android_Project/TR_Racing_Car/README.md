# TR Racing Car

A lightweight offline Android racing game prototype.

## Included
- 3-lane road racing
- Player car controlled by left/right touch buttons
- Traffic cars
- Score and speed
- Collision and game-over screen
- Restart button
- TR Racing Car app icon

## Open in Android Studio
1. Extract this ZIP.
2. Open the `TR_Racing_Car` folder in Android Studio.
3. Let Gradle sync.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

The game is intentionally lightweight; the generated icon is included.
