package com.trracingcar.game;

import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.Drawable;
import android.view.MotionEvent;
import android.view.View;

/**
 * TR Racing Car - photorealistic 2D gameplay presentation.
 * The scene is a real racing-game style background; touch zones provide
 * simple lane/boost interaction without a cartoon road renderer.
 */
public class RacingView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private Bitmap scene;
    private long lastFrame;
    private float speed = 142f;
    private int score = 0;
    private int lane = 2;
    private boolean nitro = false;
    private float nitroTimer = 0f;
    private float steerPulse = 0f;

    public RacingView(Context context) {
        super(context);
        setFocusable(true);
        scene = BitmapFactory.decodeResource(getResources(), R.drawable.racing_scene);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        long now = System.currentTimeMillis();
        if (lastFrame == 0) lastFrame = now;
        float dt = Math.min(0.05f, (now - lastFrame) / 1000f);
        lastFrame = now;

        // Full-screen cinematic scene, preserving the wide racing composition.
        drawCover(canvas, scene);

        // Subtle interaction feedback; no cartoon cars/road are drawn over the photo.
        if (nitroTimer > 0) {
            nitroTimer -= dt;
            nitro = true;
            speed = Math.min(199f, speed + 95f * dt);
            score += 2;
        } else {
            nitro = false;
            speed = Math.max(105f, speed - 18f * dt);
        }
        steerPulse = Math.max(0f, steerPulse - dt * 2.5f);

        drawInteractionHint(canvas);
        drawDynamicHud(canvas);
        postInvalidateDelayed(16);
    }

    private void drawCover(Canvas c, Bitmap b) {
        if (b == null) return;
        float sx = getWidth() / (float)b.getWidth();
        float sy = getHeight() / (float)b.getHeight();
        float scale = Math.max(sx, sy);
        float dw = b.getWidth() * scale;
        float dh = b.getHeight() * scale;
        float left = (getWidth() - dw) / 2f;
        float top = (getHeight() - dh) / 2f;
        c.drawBitmap(b, null, new RectF(left, top, left + dw, top + dh), paint);
    }

    private void drawInteractionHint(Canvas c) {
        // Invisible controls are intentionally represented by subtle touch hints.
        // The generated scene already contains steering/nitro/pedal visuals.
        float a = 55 + (int)(steerPulse * 80);
        paint.setColor(Color.argb((int)a, 255, 255, 255));
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(3f);
        float r = Math.min(getWidth(), getHeight()) * 0.075f;
        c.drawCircle(getWidth() * 0.075f, getHeight() * 0.82f, r, paint);
        c.drawCircle(getWidth() * 0.19f, getHeight() * 0.82f, r, paint);
        paint.setStyle(Paint.Style.FILL);
    }

    private void drawDynamicHud(Canvas c) {
        paint.setTypeface(Typeface.create("sans", Typeface.BOLD));
        paint.setTextAlign(Paint.Align.RIGHT);
        paint.setTextSize(Math.max(20f, getWidth() * 0.018f));
        paint.setColor(Color.WHITE);
        c.drawText("SPEED " + (int)speed + " KM/H", getWidth() - 28, getHeight() - 22, paint);
        paint.setTextSize(Math.max(18f, getWidth() * 0.015f));
        paint.setColor(Color.YELLOW);
        c.drawText("SCORE " + score, getWidth() - 28, getHeight() - 50, paint);
        paint.setTextAlign(Paint.Align.LEFT);
        if (nitro) {
            paint.setColor(Color.CYAN);
            paint.setTextSize(Math.max(18f, getWidth() * 0.016f));
            c.drawText("NITRO!", 28, getHeight() - 25, paint);
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_DOWN || e.getAction() == MotionEvent.ACTION_MOVE) {
            float x = e.getX(), y = e.getY();
            if (y > getHeight() * 0.62f) {
                if (x < getWidth() * 0.28f) {
                    lane = Math.max(1, lane - 1);
                    steerPulse = 1f;
                    score += 5;
                } else if (x > getWidth() * 0.72f) {
                    lane = Math.min(3, lane + 1);
                    steerPulse = 1f;
                    score += 5;
                } else if (x > getWidth() * 0.55f && y > getHeight() * 0.48f) {
                    nitroTimer = 1.4f;
                }
            }
            return true;
        }
        return true;
    }
}
