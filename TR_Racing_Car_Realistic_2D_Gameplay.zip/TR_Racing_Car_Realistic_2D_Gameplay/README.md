# TR Racing Car — Realistic 2D Gameplay

This edition uses a cinematic photorealistic racing scene as the actual in-game visual instead of the previous cartoon-style road renderer.

- 2D presentation (no 3D engine)
- Black supercar / wet highway / mountains / ocean
- Racing HUD, traffic, steering, nitro and pedals are part of the scene
- Touch interaction: left/right steering zones and nitro zone
- Lightweight Android project

Build with Android Studio or GitHub Actions using `./gradlew assembleDebug`.
