# TR Racing Car

A lightweight offline Android racing game prototype.

## Included
- 3-lane road racing
- Player car controlled by left/right touch buttons
- Traffic cars
- Score and speed
- Collision and game-over screen
- Restart button
- TR Racing Car app icon
- Java 17 + Kotlin Gradle compatibility for GitHub Actions

## Open in Android Studio
1. Extract this ZIP.
2. Open the `TR_Racing_Car` folder in Android Studio.
3. Let Gradle sync.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

## GitHub Actions
The project includes the Kotlin Android plugin because some Android build workflows automatically add a
`kotlinOptions` target block. This prevents the `Could not find method kotlinOptions()` build error.


## Realistic Racing Preview
The project includes `racing_preview.png`, a cinematic realistic racing-game visual, and uses the black-car racing visual for the app icon.
