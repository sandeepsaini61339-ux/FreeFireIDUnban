package com.freefire.idunban

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import android.view.Gravity
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var uid = ""

    private fun page(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(22, 24, 22, 24)
        setBackgroundColor(Color.rgb(5, 8, 16))
    }

    private fun card(): GradientDrawable = GradientDrawable().apply {
        setColor(Color.rgb(10, 16, 30))
        cornerRadius = 28f
        setStroke(2, Color.rgb(42, 55, 86))
    }

    private fun title(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 27f
        setTextColor(Color.WHITE)
        setTypeface(null, Typeface.BOLD)
        setPadding(0, 0, 0, 14)
    }

    private fun button(text: String, purple: Boolean = false): Button = Button(this).apply {
        this.text = text
        setTextColor(if (purple) Color.WHITE else Color.BLACK)
        setTypeface(null, Typeface.BOLD)
        background = GradientDrawable().apply {
            setColor(if (purple) Color.rgb(91, 61, 245) else Color.rgb(255, 210, 26))
            cornerRadius = 24f
        }
        minimumHeight = 58
    }

    private fun showUid() {
        root.removeAllViews()
        val p = page()
        p.gravity = Gravity.CENTER_HORIZONTAL

        p.addView(TextView(this).apply {
            text = "FREE FIRE
ID UNBAN"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD_ITALIC)
        })
        p.addView(TextView(this).apply {
            text = "Enter your UID to continue"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY)
            setPadding(0, 12, 0, 24)
        })

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
            background = card()
        }

        box.addView(TextView(this).apply {
            text = "FREE FIRE UID"
            textSize = 14f
            setTextColor(Color.rgb(255, 210, 26))
            setTypeface(null, Typeface.BOLD)
        })

        val uidInput = EditText(this).apply {
            hint = "Enter 9–12 digit UID"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setPadding(18, 0, 18, 0)
        }
        box.addView(uidInput, LinearLayout.LayoutParams(-1, 60).apply { topMargin = 12; bottomMargin = 16 })

        box.addView(button("CHECK BAN DETAILS").apply {
            setOnClickListener {
                val value = uidInput.text.toString().trim()
                if (!value.matches(Regex("\\d{9,12}"))) {
                    uidInput.error = "Enter a valid 9–12 digit UID"
                    return@setOnClickListener
                }
                uid = value
                showBanDetails()
            }
        })
        p.addView(box, LinearLayout.LayoutParams(-1, -2))
        root.addView(p)
    }

    private fun showBanDetails() {
        root.removeAllViews()
        val p = page()
        p.addView(title("Ban Details"))
        p.addView(TextView(this).apply {
            text = "UID: $uid"
            textSize = 18f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        })

        val details = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 20, 20, 20)
            background = card()
        }
        details.addView(TextView(this).apply {
            text = "ACCOUNT STATUS"
            textSize = 13f
            setTextColor(Color.LTGRAY)
        })
        details.addView(TextView(this).apply {
            text = "BANNED"
            textSize = 25f
            setTextColor(Color.RED)
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 5, 0, 18)
        })
        details.addView(TextView(this).apply {
            text = "Ban type: Account restriction
Appeal: Available
UID: $uid"
            textSize = 16f
            setTextColor(Color.WHITE)
            setLineSpacing(6f, 1f)
        })
        p.addView(details, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 22 })
        p.addView(TextView(this).apply {
            text = "Note: Ban information shown here is app/demo information; the app does not access Garena's private account systems."
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, 0, 0, 18)
        })
        p.addView(button("CONTINUE → PAYMENT", true).apply { setOnClickListener { showPayment() } })
        root.addView(p)
    }

    private fun showPayment() {
        root.removeAllViews()
        val p = page()
        p.addView(title("Payment"))
        p.addView(TextView(this).apply {
            text = "Scan the QR code and pay the appeal service amount"
            textSize = 15f
            setTextColor(Color.LTGRAY)
        })

        p.addView(TextView(this).apply {
            text = "₹299"
            textSize = 38f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(255, 210, 26))
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 18, 0, 10)
        })

        val iv = ImageView(this).apply {
            setImageResource(R.drawable.payment_qr)
            adjustViewBounds = true
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.WHITE)
        }
        p.addView(iv, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 8; bottomMargin = 10 })

        p.addView(TextView(this).apply {
            text = "UPI name: SUHEL ALAM"
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        })
        p.addView(button("CONTINUE TO APPEAL", true).apply { setOnClickListener { showAppeal() } })
        root.addView(p)
    }

    private fun showAppeal() {
        root.removeAllViews()
        val p = page()
        p.addView(title("Unban Appeal"))
        p.addView(TextView(this).apply {
            text = "Submit your appeal details"
            textSize = 15f
            setTextColor(Color.LTGRAY)
        })

        val uidInput = EditText(this).apply {
            hint = "UID"
            setText(uid)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine()
        }
        p.addView(uidInput, LinearLayout.LayoutParams(-1, 60).apply { topMargin = 18 })

        val reason = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Select reason", "Wrongful ban", "Account compromised", "Other"))
        }
        p.addView(reason, LinearLayout.LayoutParams(-1, 60).apply { topMargin = 10 })

        val description = EditText(this).apply {
            hint = "Explain your issue…"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            gravity = Gravity.TOP
            minLines = 5
        }
        p.addView(description, LinearLayout.LayoutParams(-1, 150).apply { topMargin = 10 })

        p.addView(button("SUBMIT APPEAL").apply {
            setOnClickListener { showDone(uidInput.text.toString().trim()) }
        })
        root.addView(p)
    }

    private fun showDone(value: String) {
        root.removeAllViews()
        val p = page()
        p.gravity = Gravity.CENTER
        p.addView(TextView(this).apply {
            text = "✓"
            textSize = 72f
            setTextColor(Color.GREEN)
            gravity = Gravity.CENTER
        })
        p.addView(title("Appeal Submitted").apply { gravity = Gravity.CENTER })
        p.addView(TextView(this).apply {
            text = "UID: ${value.ifBlank { "—" }}\nStatus: Under Review"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        })
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        setContentView(root)
        showUid()
    }
}
