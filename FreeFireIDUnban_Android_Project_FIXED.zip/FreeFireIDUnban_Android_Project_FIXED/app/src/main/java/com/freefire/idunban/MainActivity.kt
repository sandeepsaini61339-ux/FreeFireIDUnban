package com.freefire.idunban

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var uid = ""

    private fun bg(): GradientDrawable = GradientDrawable().apply {
        setColor(Color.rgb(10,16,30)); cornerRadius=28f
        setStroke(2, Color.rgb(42,55,86))
    }
    private fun btn(text:String, color:Int=Color.rgb(255,210,26)): Button =
        Button(this).apply { this.text=text; setTextColor(if(color==Color.rgb(255,210,26)) Color.BLACK else Color.WHITE)
            setTypeface(null,Typeface.BOLD); background=GradientDrawable().apply{setColor(color);cornerRadius=24f}
            minimumHeight=58; setPadding(20,0,20,0) }
    private fun title(t:String): TextView = TextView(this).apply {
        text=t; textSize=26f; setTextColor(Color.WHITE); setTypeface(null,Typeface.BOLD); setPadding(0,0,0,14)
    }
    private fun page(): LinearLayout = LinearLayout(this).apply {
        orientation=LinearLayout.VERTICAL; setPadding(22,18,22,24)
        setBackgroundColor(Color.rgb(5,8,16))
    }
    private fun showHome(){
        root.removeAllViews(); val p=page()
        p.addView(TextView(this).apply{text="FREE FIRE";textSize=30f;setTextColor(Color.WHITE);setTypeface(null,Typeface.BOLD_ITALIC);gravity=Gravity.CENTER})
        p.addView(TextView(this).apply{text="ID UNBAN";textSize=19f;setTextColor(Color.rgb(255,210,26));gravity=Gravity.CENTER;setTypeface(null,Typeface.BOLD)})
        val hero=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(22,28,22,22);background=bg()}
        hero.addView(TextView(this).apply{text="GET BACK\\nTO YOUR GAME";textSize=31f;setTextColor(Color.WHITE);setTypeface(null,Typeface.BOLD_ITALIC)})
        hero.addView(TextView(this).apply{text="Enter your UID to start the appeal workflow.";textSize=15f;setTextColor(Color.LTGRAY);setPadding(0,10,0,10)})
        hero.addView(btn("GET STARTED →").apply{setOnClickListener{showUid()}})
        p.addView(hero, LinearLayout.LayoutParams(-1,-2))
        val scan=btn("🔎  SCAN UID"); scan.setOnClickListener{showUid()}; p.addView(scan)
        val qr=btn("▦  SCAN & PAY",Color.rgb(91,61,245)); qr.setOnClickListener{showQr()}; p.addView(qr)
        val appeal=btn("📝  UNBAN APPEAL"); appeal.setOnClickListener{showAppeal()}; p.addView(appeal)
        root.addView(p)
    }
    private fun showUid(){
        root.removeAllViews(); val p=page()
        p.addView(title("Enter UID"))
        p.addView(TextView(this).apply{text="Enter your Free Fire UID to start the scanner.";textSize=14f;setTextColor(Color.LTGRAY)})
        val e=EditText(this).apply{hint="Enter 9–12 digit UID";setTextColor(Color.WHITE);setHintTextColor(Color.GRAY);inputType=InputType.TYPE_CLASS_NUMBER;setSingleLine();setPadding(20,0,20,0)}
        p.addView(e,LinearLayout.LayoutParams(-1,60).apply{topMargin=20;bottomMargin=14})
        p.addView(btn("SCAN UID").apply{setOnClickListener{
            val v=e.text.toString().trim()
            if(!v.matches(Regex("\\d{9,12}"))){e.error="Enter a valid 9–12 digit UID";return@setOnClickListener}
            uid=v; showScan()
        }})
        p.addView(btn("VIEW QR CODE",Color.rgb(91,61,245)).apply{setOnClickListener{showQr()}})
        root.addView(p)
    }
    private fun showScan(){
        root.removeAllViews(); val p=page()
        p.addView(title("Scanning UID…"))
        p.addView(TextView(this).apply{text="Scanning in demo mode…";textSize=15f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER})
        val box=FrameLayout(this).apply{background=GradientDrawable().apply{setColor(Color.rgb(8,20,38));cornerRadius=30f;setStroke(3,Color.CYAN)}}
        val sp=ProgressBar(this).apply{isIndeterminate=true}
        box.addView(sp,FrameLayout.LayoutParams(70,70,Gravity.CENTER))
        p.addView(box,LinearLayout.LayoutParams(-1,310).apply{topMargin=22;bottomMargin=22})
        root.addView(p)
        box.postDelayed({showAccount()},1400)
    }
    private fun showAccount(){
        root.removeAllViews(); val p=page()
        p.addView(title("Account Details"))
        val card=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,18,20,18);background=bg()}
        card.addView(TextView(this).apply{text="UID: $uid";textSize=18f;setTextColor(Color.WHITE);setTypeface(null,Typeface.BOLD)})
        card.addView(TextView(this).apply{text="Account Status: BANNED";textSize=16f;setTextColor(Color.RED);setPadding(0,16,0,6)})
        card.addView(TextView(this).apply{text="Appeal: Ready to submit";textSize=14f;setTextColor(Color.LTGRAY)})
        p.addView(card)
        p.addView(btn("SUBMIT UNBAN APPEAL").apply{setOnClickListener{showAppeal()}})
        p.addView(btn("VIEW QR CODE",Color.rgb(91,61,245)).apply{setOnClickListener{showQr()}})
        root.addView(p)
    }
    private fun showQr(){
        root.removeAllViews(); val p=page()
        p.addView(title("Scan & Pay"))
        p.addView(TextView(this).apply{text="QR code supplied for this app.";textSize=14f;setTextColor(Color.LTGRAY)})
        val iv=ImageView(this).apply{setImageResource(com.freefire.idunban.R.drawable.payment_qr);adjustViewBounds=true;setPadding(18,18,18,18);setBackgroundColor(Color.WHITE)}
        p.addView(iv,LinearLayout.LayoutParams(-1,0,1f).apply{topMargin=18;bottomMargin=12})
        p.addView(TextView(this).apply{text="SUHEL ALAM";textSize=16f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;setTypeface(null,Typeface.BOLD)})
        p.addView(btn("CONTINUE TO APPEAL").apply{setOnClickListener{showAppeal()}})
        root.addView(p)
    }
    private fun showAppeal(){
        root.removeAllViews(); val p=page()
        p.addView(title("Unban Appeal"))
        val uidE=EditText(this).apply{hint="UID";setText(uid);setTextColor(Color.WHITE);setHintTextColor(Color.GRAY);inputType=InputType.TYPE_CLASS_NUMBER;setSingleLine()}
        p.addView(uidE,LinearLayout.LayoutParams(-1,60))
        val reason=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("Select reason","Wrongful ban","Account compromised","Other"))}
        p.addView(reason,LinearLayout.LayoutParams(-1,60).apply{topMargin=10})
        val desc=EditText(this).apply{hint="Explain your issue…";setTextColor(Color.WHITE);setHintTextColor(Color.GRAY);gravity=Gravity.TOP;minLines=5}
        p.addView(desc,LinearLayout.LayoutParams(-1,150).apply{topMargin=10})
        p.addView(btn("SUBMIT APPEAL").apply{setOnClickListener{showDone(uidE.text.toString())}})
        root.addView(p)
    }
    private fun showDone(v:String){
        root.removeAllViews(); val p=page()
        p.gravity=Gravity.CENTER
        p.addView(TextView(this).apply{text="✓";textSize=72f;setTextColor(Color.GREEN);gravity=Gravity.CENTER})
        p.addView(title("Appeal Submitted").apply{gravity=Gravity.CENTER})
        p.addView(TextView(this).apply{text="UID: ${v.ifBlank{"—"}}\\nStatus: Under Review";textSize=16f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER})
        p.addView(btn("BACK TO HOME").apply{setOnClickListener{showHome()}})
        root.addView(p)
    }
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);root=LinearLayout(this);root.orientation=LinearLayout.VERTICAL;setContentView(root);showHome()}
}
