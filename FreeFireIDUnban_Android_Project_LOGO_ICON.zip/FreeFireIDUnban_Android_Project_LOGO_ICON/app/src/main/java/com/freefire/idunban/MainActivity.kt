package com.freefire.idunban

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private var uid: String = ""

    private fun page(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(22, 24, 22, 24)
        setBackgroundColor(Color.rgb(5, 8, 16))
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(20, 20, 20, 20)
        background = GradientDrawable().apply {
            setColor(Color.rgb(10, 16, 30))
            cornerRadius = 28f
            setStroke(2, Color.rgb(42, 55, 86))
        }
    }

    private fun title(text: String): TextView = TextView(this).apply {
        this.text = text
        textSize = 27f
        setTextColor(Color.WHITE)
        setTypeface(null, Typeface.BOLD)
        setPadding(0, 0, 0, 14)
    }

    private fun button(text: String, purple: Boolean = false): Button = Button(this).apply {
        this.text = text
        textSize = 15f
        setTypeface(null, Typeface.BOLD)
        setTextColor(if (purple) Color.WHITE else Color.BLACK)
        background = GradientDrawable().apply {
            setColor(if (purple) Color.rgb(91, 61, 245) else Color.rgb(255, 210, 26))
            cornerRadius = 24f
        }
        minimumHeight = 58
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        setContentView(root)
        showUidScreen()
    }

    // 1) App opens directly on UID screen.
    private fun showUidScreen() {
        root.removeAllViews()
        val p = page()

        val logo = TextView(this).apply {
            text = "FREE FIRE\nID UNBAN"
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD_ITALIC)
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 28)
        }
        p.addView(logo, LinearLayout.LayoutParams(-1, -2))
        p.addView(title("Enter UID"))
        p.addView(TextView(this).apply {
            text = "Enter your Free Fire UID to check the account status."
            textSize = 15f
            setTextColor(Color.LTGRAY)
        })

        val input = EditText(this).apply {
            hint = "Enter 9–12 digit UID"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
            setPadding(20, 0, 20, 0)
        }
        p.addView(input, LinearLayout.LayoutParams(-1, 62).apply {
            topMargin = 22
            bottomMargin = 16
        })

        p.addView(button("CHECK UID →").apply {
            setOnClickListener {
                val value = input.text.toString().trim()
                if (!value.matches(Regex("\\d{9,12}"))) {
                    input.error = "Enter a valid 9–12 digit UID"
                    return@setOnClickListener
                }
                uid = value
                showScanner()
            }
        })

        p.addView(TextView(this).apply {
            text = "Demo/support workflow — it does not bypass Garena systems."
            textSize = 12f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 20, 0, 0)
        })

        root.addView(p)
    }

    // 2) Scanner animation, then account details.
    private fun showScanner() {
        root.removeAllViews()
        val p = page()
        p.addView(title("Checking UID…"))
        p.addView(TextView(this).apply {
            text = "Please wait while the demo scanner checks the entered UID."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        })

        val box = FrameLayout(this).apply {
            background = GradientDrawable().apply {
                setColor(Color.rgb(8, 20, 38))
                cornerRadius = 30f
                setStroke(3, Color.CYAN)
            }
        }
        box.addView(ProgressBar(this), FrameLayout.LayoutParams(72, 72, Gravity.CENTER))
        p.addView(box, LinearLayout.LayoutParams(-1, 300).apply {
            topMargin = 24
            bottomMargin = 24
        })
        root.addView(p)

        box.postDelayed({ showAccountDetails() }, 1300)
    }

    private fun showAccountDetails() {
        root.removeAllViews()
        val p = page()
        p.addView(title("Account Details"))

        val c = card()
        c.addView(TextView(this).apply {
            text = "UID: $uid"
            textSize = 19f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
        })
        c.addView(TextView(this).apply {
            text = "Account Status: BANNED"
            textSize = 17f
            setTextColor(Color.RED)
            setPadding(0, 16, 0, 8)
        })
        c.addView(TextView(this).apply {
            text = "Appeal status: Ready to submit"
            textSize = 14f
            setTextColor(Color.LTGRAY)
        })
        p.addView(c, LinearLayout.LayoutParams(-1, -2))

        p.addView(button("CONTINUE → PAYMENT").apply {
            setOnClickListener { showPayment() }
        })
        root.addView(p)
    }

    // 3) QR + exact amount 299.
    private fun showPayment() {
        root.removeAllViews()
        val p = page()
        p.addView(title("Payment"))
        p.addView(TextView(this).apply {
            text = "Scan the QR code and pay the displayed amount."
            textSize = 15f
            setTextColor(Color.LTGRAY)
        })

        val amount = TextView(this).apply {
            text = "₹299"
            textSize = 34f
            setTextColor(Color.rgb(255, 210, 26))
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 18)
        }
        p.addView(amount)

        val qr = ImageView(this).apply {
            setImageResource(R.drawable.payment_qr)
            adjustViewBounds = true
            setPadding(18, 18, 18, 18)
            setBackgroundColor(Color.WHITE)
        }
        p.addView(qr, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            topMargin = 6
            bottomMargin = 12
        })

        p.addView(TextView(this).apply {
            text = "Payment name: SUHEL ALAM"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setTypeface(null, Typeface.BOLD)
            setPadding(0, 0, 0, 12)
        })

        p.addView(button("CONTINUE TO APPEAL").apply {
            setOnClickListener { showAppeal() }
        })
        root.addView(p)
    }

    // 4) Appeal form.
    private fun showAppeal() {
        root.removeAllViews()
        val p = page()
        p.addView(title("Unban Appeal"))
        p.addView(TextView(this).apply {
            text = "Fill in the appeal details and submit them for review."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, 12)
        })

        val uidInput = EditText(this).apply {
            hint = "UID"
            setText(uid)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_NUMBER
            setSingleLine(true)
        }
        p.addView(uidInput, LinearLayout.LayoutParams(-1, 60))

        val reason = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Select reason", "Wrongful ban", "Account compromised", "Other")
            )
        }
        p.addView(reason, LinearLayout.LayoutParams(-1, 60).apply { topMargin = 10 })

        val message = EditText(this).apply {
            hint = "Explain your issue…"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            gravity = Gravity.TOP
            minLines = 5
        }
        p.addView(message, LinearLayout.LayoutParams(-1, 150).apply { topMargin = 10 })

        p.addView(button("SUBMIT APPEAL").apply {
            setOnClickListener { showSubmitted(uidInput.text.toString().trim()) }
        })
        root.addView(p)
    }

    private fun showSubmitted(submittedUid: String) {
        root.removeAllViews()
        val p = page().apply { gravity = Gravity.CENTER }
        p.addView(TextView(this).apply {
            text = "✓"
            textSize = 72f
            setTextColor(Color.GREEN)
            gravity = Gravity.CENTER
        })
        p.addView(TextView(this).apply {
            text = "Appeal Submitted"
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER
        })
        p.addView(TextView(this).apply {
            text = "UID: ${if (submittedUid.isBlank()) "—" else submittedUid}\nStatus: Under Review"
            textSize = 16f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 24)
        })
        p.addView(button("BACK TO UID").apply {
            setOnClickListener { showUidScreen() }
        })
        root.addView(p)
    }
}
