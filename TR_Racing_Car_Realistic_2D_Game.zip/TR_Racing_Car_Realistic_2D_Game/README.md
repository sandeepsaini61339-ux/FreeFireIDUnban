# TR Racing Car — Realistic 2D Edition

This project is a 2D realistic-style racing game prototype.

Gameplay:
- Realistic-style highway visual
- Dark/black player car
- Traffic cars
- 3-lane road
- Left/right steering buttons
- Speed and score HUD
- Collision and restart
- No 3D engine

The project is intentionally lightweight so it can target a small APK size.

Build:
1. Open in Android Studio, or use GitHub Actions.
2. Run `./gradlew assembleDebug`.
3. APK: `app/build/outputs/apk/debug/app-debug.apk`
