package com.trracingcar.game;

import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import java.util.Random;

public class RacingView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random random = new Random();
    private long last = 0;
    private float playerX, playerY;
    private float roadLeft, roadRight, laneW;
    private float speed = 0.42f;
    private int score = 0;
    private boolean gameOver = false;
    private float spawnTimer = 0;
    private final float[] enemyX = new float[6];
    private final float[] enemyY = new float[6];
    private final boolean[] active = new boolean[6];
    private float leftBtnL, leftBtnT, rightBtnL, rightBtnT, btnS;

    public RacingView(Context c) {
        super(c);
        p.setTypeface(Typeface.create("sans", Typeface.BOLD));
        setFocusable(true);
    }

    private void reset() {
        score = 0; speed = 0.42f; gameOver = false; spawnTimer = 0;
        for (int i=0;i<active.length;i++) active[i]=false;
        postInvalidate();
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        int w=getWidth(), h=getHeight();
        if (last==0) last=System.currentTimeMillis();
        float dt=Math.min(0.05f,(System.currentTimeMillis()-last)/1000f);
        last=System.currentTimeMillis();

        // Sky
        p.setStyle(Paint.Style.FILL);
        p.setColor(Color.rgb(40,75,120)); c.drawRect(0,0,w,h,p);

        // Grass
        p.setColor(Color.rgb(24,92,38)); c.drawRect(0,0,w,h,p);

        // Road trapezoid
        roadLeft=w*0.20f; roadRight=w*0.80f; laneW=(roadRight-roadLeft)/3f;
        Path road=new Path();
        road.moveTo(w*0.38f,0); road.lineTo(w*0.62f,0);
        road.lineTo(roadRight,h); road.lineTo(roadLeft,h); road.close();
        p.setColor(Color.rgb(48,48,52)); c.drawPath(road,p);

        // Road edges
        p.setColor(Color.WHITE); p.setStrokeWidth(7);
        c.drawLine(w*0.38f,0,roadLeft,h,p); c.drawLine(w*0.62f,0,roadRight,h,p);

        // Moving lane dashes
        float dashOffset=(score*12)%90;
        p.setStrokeWidth(5); p.setColor(Color.rgb(235,235,235));
        for(int lane=1;lane<=2;lane++){
            float xTop=w*(0.38f + lane*0.08f);
            float xBot=roadLeft+lane*laneW;
            for(float y=-100+dashOffset;y<h;y+=105){
                float t=y/h;
                float x=xTop+(xBot-xTop)*t;
                float len=36+45*t;
                c.drawLine(x,y,x,y+len,p);
            }
        }

        // Update enemies
        if(!gameOver){
            spawnTimer += dt;
            if(spawnTimer>0.9f){
                spawnTimer=0;
                for(int i=0;i<active.length;i++) if(!active[i]){
                    active[i]=true; enemyY[i]=-150;
                    enemyX[i]=roadLeft + (random.nextInt(3)+0.5f)*laneW;
                    break;
                }
            }
            for(int i=0;i<active.length;i++) if(active[i]){
                enemyY[i]+= (220+speed*260)*dt;
                drawCar(c, enemyX[i], enemyY[i], 42, 74, Color.rgb(245,190,35), false);
                if(enemyY[i]>h+120){ active[i]=false; score++; if(score%10==0) speed=Math.min(0.75f,speed+0.035f); }
            }
        }

        // Player
        if(playerY==0) { playerY=h*0.78f; playerX=roadLeft+1.5f*laneW; }
        if(!gameOver) {
            drawCar(c,playerX,playerY,48,82,Color.rgb(220,35,35),true);
            for(int i=0;i<active.length;i++) if(active[i] && hit(playerX,playerY,enemyX[i],enemyY[i])){
                gameOver=true;
            }
        } else {
            drawCar(c,playerX,playerY,48,82,Color.rgb(220,35,35),true);
        }

        // HUD
        p.setColor(Color.WHITE); p.setTextSize(28);
        c.drawText("TR RACING CAR",24,42,p);
        p.setTextSize(22); c.drawText("Score: "+score,24,72,p);
        c.drawText("Speed: "+(int)(speed*100)+" km/h",24,100,p);

        // Controls
        btnS=Math.min(w,h)*0.15f;
        leftBtnL=25; leftBtnT=h-btnS-25;
        rightBtnL=w-btnS-25; rightBtnT=h-btnS-25;
        drawButton(c,leftBtnL,leftBtnT,btnS,"◀");
        drawButton(c,rightBtnL,rightBtnT,btnS,"▶");

        if(gameOver){
            p.setColor(0x99000000); c.drawRect(0,0,w,h,p);
            p.setColor(Color.WHITE); p.setTextAlign(Paint.Align.CENTER);
            p.setTextSize(52); c.drawText("RACE OVER",w/2f,h/2f-35,p);
            p.setTextSize(25); c.drawText("Score: "+score,w/2f,h/2f+10,p);
            p.setTextSize(22); c.drawText("Tap anywhere to restart",w/2f,h/2f+55,p);
            p.setTextAlign(Paint.Align.LEFT);
        }
        postInvalidateDelayed(16);
    }

    private void drawButton(Canvas c,float x,float y,float s,String txt){
        p.setColor(0xAA111111); c.drawRoundRect(x,y,x+s,y+s,24,24,p);
        p.setColor(Color.WHITE); p.setTextSize(s*0.42f); p.setTextAlign(Paint.Align.CENTER);
        c.drawText(txt,x+s/2,y+s*0.64f,p); p.setTextAlign(Paint.Align.LEFT);
    }

    private void drawCar(Canvas c,float x,float y,float ww,float hh,int color,boolean player){
        p.setColor(color); c.drawRoundRect(x-ww/2,y-hh/2,x+ww/2,y+hh/2,14,14,p);
        p.setColor(Color.rgb(25,35,45));
        c.drawRoundRect(x-ww*0.32f,y-hh*0.28f,x+ww*0.32f,y+hh*0.03f,8,8,p);
        p.setColor(Color.WHITE); c.drawRect(x-ww*0.38f,y-hh*0.43f,x-ww*0.18f,y-hh*0.32f,p);
        c.drawRect(x+ww*0.18f,y-hh*0.43f,x+ww*0.38f,y-hh*0.32f,p);
        p.setColor(Color.BLACK);
        c.drawCircle(x-ww*0.47f,y-hh*0.28f,ww*0.11f,p); c.drawCircle(x+ww*0.47f,y-hh*0.28f,ww*0.11f,p);
        c.drawCircle(x-ww*0.47f,y+hh*0.30f,ww*0.11f,p); c.drawCircle(x+ww*0.47f,y+hh*0.30f,ww*0.11f,p);
        if(player){
            p.setColor(Color.rgb(255,225,35)); c.drawCircle(x,y-hh*0.44f,4,p);
        }
    }

    private boolean hit(float ax,float ay,float bx,float by){
        return Math.abs(ax-bx)<45 && Math.abs(ay-by)<70;
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()!=MotionEvent.ACTION_DOWN && e.getAction()!=MotionEvent.ACTION_MOVE) return true;
        float x=e.getX(), y=e.getY();
        if(gameOver){ if(e.getAction()==MotionEvent.ACTION_DOWN) reset(); return true; }
        if(y>getHeight()-btnS-45){
            if(x<getWidth()/2f) playerX-=laneW*0.045f;
            else playerX+=laneW*0.045f;
            playerX=Math.max(roadLeft+laneW*0.5f,Math.min(roadRight-laneW*0.5f,playerX));
        }
        return true;
    }
}
